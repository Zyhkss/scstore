const body = document.body
const navbar = document.querySelector('#lope')
const jumbotron = document.querySelector('#jbt')
const about = document.querySelector('#about')
const btnabout = document.querySelector('#btnabout')
const btnhome = document.querySelector('#btnhome')

function codashop() {
    window.location.href = "http://4.193.37.48/~webpppppp/";
}

function ffspin() {
    window.location.href = "https://tampilan-webp-aw-cod.portz.my.id/";
}

function mlspin() {
    window.location.href = "https://tampilan-webp-aw-cod.portz.my.id/ml-spin/"
}

// const home = document.querySelector('body')



// btnabout.addEventListener("click", function() {
//     // Cek apakah alert sedang ditampilkan atau disembunyikan
//     if (about.classList.contains('d-none')) {
//     // Jika about disembunyikan, maka tampilkan about
//     about.classList.remove('d-none');
// } else {
//     if (jumbotron.classList.contains('d-block')) {
//     // Jika about ditampilkan, maka sembunyikan jumbotron
//     jumbotron.classList.remove('d-block');
//     jumbotron.classList.add("d-none")
//     }

// }
// }
// )

// jumbotron.addEventListener('click', function() {
//     if (body.classList.contains(d-none)) {
//         body.classList.add('d-none')
//     }
// }
// )





    